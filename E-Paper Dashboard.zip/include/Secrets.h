#ifndef SECRETS_H_
#define SECRETS_H_

#define XSTR(x) #x
#define STR(x) XSTR(x)

#define WIFI_SSID "UPC6905710"
#define WIFI_PASSWD "a3dknjffwnMy"
#define HOSTNAME "Dashboard"
#define DASHBOARD_URL "http://192.168.178.35:1880/dashboard"
#define DASHBOARD_LOG_URL "http://192.168.178.35:1880/dashboard-log"
const byte bssid[] = {0x3C, 0xA6, 0x2F, 0x57, 0x16, 0xB9};

#endif /* SECRETS_H_ */